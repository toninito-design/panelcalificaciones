# Panel de calificaciones

Web estática en español para importar informes de evaluación y consultar resultados por materia, curso, grupo y trimestre. Incluye fichas de alumnado, observaciones, PDF y copia del histórico.

Abre `dist/index.html` desde un servidor estático. Para GitHub Pages, pon el contenido de `dist/` en la raíz de la rama publicada. El análisis y el almacenamiento ocurren en el navegador. El código fuente se puede distribuir sin los Excel ni sus datos.

El importador reconoce informes ALXe con cabeceras repetidas y columnas de evaluación, media y materias. Admite archivos XLS, XLSX y CSV con esa estructura. Una calificación numérica de 0 cuenta como suspenso y las celdas sin nota quedan fuera de los cálculos. Los informes de distintas evaluaciones se importan por separado, salvo que el archivo ya incluya varias evaluaciones. Las fichas enlazan al alumnado por nombre dentro de un mismo año, curso y grupo.

## Acta de evaluación

La pestaña Acta de evaluación se organiza en primer, segundo y tercer trimestre y final. Usa el grupo y año seleccionados para obtener las notas del histórico. El apartado 6 conserva el espacio para el profesorado y las propuestas de mejora automáticas se incluyen en el apartado 7. Las aportaciones y el tutor se guardan en el navegador y se incluyen en la copia del histórico. Cada evaluación se exporta a PDF y las cuatro juntas a un Word editable.
